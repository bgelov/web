# 2.2, 2015-03-25 [details](http://dedushka.org/kod/7767.html)

## Fixed issues from the previous version:

- Fixed the built-in forms (with no popup). It's easy to make the Callme to get data from any of the forms on the page. Read the manual for further instructions
- You can get find out what link was clicked to view the callme form. So it's the new easy way to count conversions. Add a new attribute data-cme="your title" to any object with class .callme_viewform. That's how you'll know which link is the most popular.
- new yellow/black template
- other small fixes

## More

- See the [main manual](http://dedushka.org/kod/5213.html) with the settings
- Read more [about the Callme](http://dedushka.org/blog/7768.html), find out what's it and how to work with the script (in Russian).
- See the [demo page](http://dedushka.org/callme/) to see Callme working.
- Know out how to [set up the SMTP](http://qbx.me/viewtopic.php?t=108)
- See the [SMS-settings manual](http://dedushka.org/kod/3903.html)

## Don't miss

- [Twitter](http://twitter.com/dedushkaa)
- [Forum](http://qbx.me)
- [Blog](http://dedushka.org)